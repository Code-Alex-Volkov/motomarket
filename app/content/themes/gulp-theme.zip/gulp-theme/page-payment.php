<?php get_header(); ?>   

<div class="wrapper">
	<div class="content-payment">
		<?php the_content(); ?>
		<a class="go-home" href="<?php echo home_url(); ?>">На главную</a>
	</div>
</div>

<?php get_footer(); ?>